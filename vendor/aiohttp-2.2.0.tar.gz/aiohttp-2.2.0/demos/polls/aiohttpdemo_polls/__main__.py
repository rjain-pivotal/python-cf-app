import sys

from aiohttpdemo_polls.main import main


main(sys.argv[1:])
